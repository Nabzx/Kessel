Serve this folder with python3 -m http.server 8000, then open http://127.0.0.1:8000/.
Finite measured synthetic recordings. Neural continuous actions use disclosed rule-based phase memory. No live browser inference or machine control. Training tools and weights remain in the full repository.
