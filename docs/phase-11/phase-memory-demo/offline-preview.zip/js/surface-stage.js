import {sampleSurfaceHaul} from "./surface-motion.js";
import { vegetation, yardActivity } from "./site-detail.js";
import { authoredAsset } from "./authored-assets.js";
import * as THREE from "three";
import { texture, box, lightRig, seeded, line, varyTexture } from "./scene-utils.js";
import { createVehicle } from "./vehicle.js";
import { rockMaterial, rockBody } from "./geology.js";
export async function createSurface(config) {
  const root = new THREE.Group();
  root.name = "rutongo-surface";
  const data = config.assets.surface;
  const design = config.visuals.surface;
  const [satellite, heightMap, soil, rockMat, soilNormal, aggregate, vehicleModel, grass, grassNormal, grassRough, haul] = await Promise.all([
    texture(data.satellite_image),
    new THREE.TextureLoader().loadAsync(data.elevation_heightmap),
    texture(data.detail_map),
    rockMaterial(config.visuals.rock),
    texture(config.assets.floor_normal, 17, false),
    texture(config.assets.ore),
    fetch(config.assets.truck, { cache: "no-store" }).then(r => r.json()),
    texture(design.ground.diff), texture(design.ground.normal,1,false), texture(design.ground.roughness,1,false),
    fetch("data/surface-haul.json").then(r=>{if(!r.ok)throw Error("Surface haul unavailable");return r.json();}),
  ]);
  rockMat.userData.vegetationMap=grass;
  const prepareRock=rockMat.onBeforeCompile;
  rockMat.onBeforeCompile=shader=>{
    prepareRock.call(rockMat,shader);shader.uniforms.vegetationMap={value:grass};
    shader.fragmentShader="uniform sampler2D vegetationMap;\n"+shader.fragmentShader.replace("float strata=",`float vegetation=smoothstep(.58,.85,rockN.y)*smoothstep(4.0,12.0,rockPosition.y);
      vec3 plants=texture2D(vegetationMap,rockPosition.xz/15.0).rgb*vec3(.7,.9,.6);
      rockTex=mix(rockTex,plants,vegetation*.85);
      float strata=`);
  };
  rockMat.customProgramCacheKey=()=>"kessel-surface-geology-v2";
  const image = heightMap.image,
    canvas = document.createElement("canvas");
  canvas.width = image.width;
  canvas.height = image.height;
  const context = canvas.getContext("2d", { willReadFrequently: true });
  context.drawImage(image, 0, 0);
  const values = context.getImageData(0, 0, image.width, image.height).data;
  const [originX, , originZ] = data.site_origin_m;
  function raw(x, z) {
    const fx = THREE.MathUtils.clamp(
        ((x + originX + data.width_m / 2) / data.width_m) * (image.width - 1),
        0,
        image.width - 1,
      ),
      fy = THREE.MathUtils.clamp(
        ((z + originZ + data.width_m / 2) / data.width_m) * (image.height - 1),
        0,
        image.height - 1,
      );
    const x0 = Math.floor(fx),
      y0 = Math.floor(fy),
      x1 = Math.min(x0 + 1, image.width - 1),
      y1 = Math.min(y0 + 1, image.height - 1);
    const sample = (a, b) => values[(b * image.width + a) * 4] / 255;
    return (
      THREE.MathUtils.lerp(
        THREE.MathUtils.lerp(sample(x0, y0), sample(x1, y0), fx - x0),
        THREE.MathUtils.lerp(sample(x0, y1), sample(x1, y1), fx - x0),
        fy - y0,
      ) *
      (data.elevation_max_m - data.elevation_min_m)
    );
  }
  const zero = raw(0, 0);
  const elevation = (x, z) =>
    THREE.MathUtils.lerp(
      0,
      raw(x, z) - zero,
      THREE.MathUtils.smoothstep(Math.hypot(x, z), 115, 240),
    );
  const geometry = new THREE.PlaneGeometry(
    data.width_m,
    data.width_m,
    128,
    128,
  );
  geometry.rotateX(-Math.PI / 2);
  const positions = geometry.attributes.position;
  for (let i = 0; i < positions.count; i++) {
    const x = positions.getX(i) - originX,
      z = positions.getZ(i) - originZ;
    positions.setXYZ(i, x, elevation(x, z), z);
  }
  geometry.computeVertexNormals();
  const terrainMaterial = new THREE.MeshStandardMaterial({
    map: satellite,
    roughness: 1,
  });
  Object.assign(terrainMaterial.userData,{detailMap:grass,detailNormal:grassNormal,detailRough:grassRough});
  terrainMaterial.onBeforeCompile = (shader) => {
    shader.uniforms.detailMap = { value: grass };
    shader.uniforms.detailNormal = {value:grassNormal};
    shader.uniforms.detailRough = {value:grassRough};
    shader.vertexShader =
      "varying vec3 terrainPosition;\n" +
      shader.vertexShader.replace(
        "#include <begin_vertex>",
        "#include <begin_vertex>\nterrainPosition=position;",
      );
    shader.fragmentShader =
      "uniform sampler2D detailMap,detailNormal,detailRough;\nvarying vec3 terrainPosition;\n" +
      shader.fragmentShader.replace(
        "#include <map_fragment>",
        `#include <map_fragment>
 vec2 groundUV=terrainPosition.xz/15.0;
 vec3 detail=mix(texture2D(detailMap,groundUV).rgb,texture2D(detailMap,groundUV*.73+vec2(.37,.62)).rgb,.4);
 float terrainPatch=sin(terrainPosition.x*.018+sin(terrainPosition.z*.025)*3.0)*sin(terrainPosition.z*.034);
 vec3 localGround=detail*mix(vec3(.73,.78,.64),vec3(.80,.83,.70),smoothstep(-.45,.7,terrainPatch));
 diffuseColor.rgb=mix(localGround,diffuseColor.rgb,smoothstep(180.0,850.0,length(terrainPosition.xz)));
 `,
      );
    shader.fragmentShader=shader.fragmentShader.replace("#include <roughnessmap_fragment>",`#include <roughnessmap_fragment>
      roughnessFactor=mix(texture2D(detailRough,terrainPosition.xz/15.0).r,1.0,smoothstep(180.0,850.0,length(terrainPosition.xz)));`);
    shader.fragmentShader=shader.fragmentShader.replace("#include <normal_fragment_maps>",`#include <normal_fragment_maps>
      vec3 n=texture2D(detailNormal,terrainPosition.xz/15.0).xyz*2.0-1.0;
      normal=normalize(normal+mat3(viewMatrix)*vec3(n.x,n.z-1.0,n.y)*.35*(1.0-smoothstep(180.0,850.0,length(terrainPosition.xz))));
    `);
  };
  const terrain = new THREE.Mesh(geometry, terrainMaterial);
  terrain.receiveShadow = true;
  root.add(terrain);
  const yardMap = soil.clone();
  yardMap.repeat.set(17, 14);
  const yardMat = new THREE.MeshStandardMaterial({
    map: yardMap,
    normalMap: soilNormal,
    normalScale: new THREE.Vector2(0.3, 0.3),
    color: 0xa2a799,
    roughness: 1,
  });
  const yardShape = new THREE.Shape(design.yard_outline.map(([x, z]) => new THREE.Vector2(x, -z)));
  const yardGeometry = new THREE.ShapeGeometry(yardShape, 1);
  yardGeometry.rotateX(-Math.PI / 2);
  const uv = yardGeometry.attributes.uv, yardPositions = yardGeometry.attributes.position;
  for (let i = 0; i < uv.count; i++) uv.setXY(i, yardPositions.getX(i) / 5, yardPositions.getZ(i) / 5);
  yardMap.repeat.set(1, 1); soilNormal.repeat.set(1, 1);
  yardMat.transparent = true;
  yardMat.onBeforeCompile = (shader) => {
    shader.uniforms.yardOutline = { value: design.yard_outline.map(p => new THREE.Vector2(...p)) };
    shader.vertexShader = "varying vec2 yardPoint;\n" + shader.vertexShader.replace("#include <begin_vertex>", "#include <begin_vertex>\nyardPoint=position.xz;");
    shader.fragmentShader = "uniform vec2 yardOutline[10]; varying vec2 yardPoint;\n" + shader.fragmentShader.replace("#include <alphatest_fragment>", `
      float edgeDistance=1000.0;
      for(int i=0;i<10;i++){vec2 a=yardOutline[i],b=yardOutline[(i+1)%10],v=b-a;
        float t=clamp(dot(yardPoint-a,v)/dot(v,v),0.0,1.0);edgeDistance=min(edgeDistance,length(yardPoint-a-v*t));}
      diffuseColor.a*=smoothstep(0.0,4.0,edgeDistance);
      #include <alphatest_fragment>`);
  };
  varyTexture(yardMat);
  yardMat.customProgramCacheKey=()=>"kessel-authored-yard-edge-v1";
  const yard = new THREE.Mesh(yardGeometry, yardMat);
  yard.position.y = .14; yard.receiveShadow = true; root.add(yard);
  const buildingMat = new THREE.MeshStandardMaterial({
    color: 0x81877d,
    roughness: 0.75,
  });
  const metal = new THREE.MeshStandardMaterial({
    color: 0x626e70,
    roughness: 0.57,
    metalness: 0.75,
  });
  const dark = new THREE.MeshStandardMaterial({
    color: 0x293b41,
    roughness: 0.5,
  });
  for (const spec of data.buildings) {
    const [x, , z] = spec.position,
      [w, h, d] = spec.size;
    box([w, h, d], [x, h / 2, z], buildingMat, root);
    const roof = box([w + 1.8, .25, d + 1.8], [x, h + .4, z], metal, root);
    roof.rotation.z = .045;
    const ribCount = Math.ceil(w / .75);
    const ribs = new THREE.InstancedMesh(new THREE.BoxGeometry(.055, .1, d + 1.8), metal, ribCount);
    const ribPose = new THREE.Object3D();
    for (let i = 0; i < ribCount; i++) {
      const offset = (i / (ribCount - 1) - .5) * (w + 1.8);
      ribPose.position.set(x + offset, h + .58 + offset * .045, z); ribPose.updateMatrix(); ribs.setMatrixAt(i, ribPose.matrix);
    }
    root.add(ribs);
    const cladding = new THREE.InstancedMesh(new THREE.BoxGeometry(.045, h - .3, .08), metal, Math.ceil(w / 1.2));
    for (let i = 0; i < cladding.count; i++) {
      ribPose.position.set(x - w / 2 + i * 1.2, h / 2, z + d / 2 + .06); ribPose.updateMatrix(); cladding.setMatrixAt(i, ribPose.matrix);
    }
    root.add(cladding);
    for (const side of [-1, 1]) {
      box([.16, h, .16], [x + side * (w / 2 - .4), h / 2, z + d / 2 + .15], metal, root);
      box([w * .32, .2, 1.5], [x + side * w * .3, h * .77, z + d / 2 + .7], metal, root);
    }
    box(
      [w * 0.35, h * 0.75, 0.1],
      [x, h * 0.375, z + d / 2 + 0.08],
      dark,
      root,
    );
    for (const side of [-1, 1])
      box(
        [2.8, 1.5, 0.12],
        [x + side * w * 0.32, h * 0.6, z + d / 2 + 0.1],
        dark,
        root,
      );
  }
  const portal = new THREE.Group();
  portal.position.fromArray(data.portal_position);
  root.add(portal);
  // An open, extruded collar and recessed tunnel, rather than a black decal on a box.
  const half = design.portal_width_m / 2, height = design.portal_height_m;
  const outline = new THREE.Shape();
  outline.moveTo(-half - 1.4, 0); outline.lineTo(-half - 1.4, height * .55);
  outline.quadraticCurveTo(-half - 1.4, height + 1.3, 0, height + 1.3);
  outline.quadraticCurveTo(half + 1.4, height + 1.3, half + 1.4, height * .55);
  outline.lineTo(half + 1.4, 0); outline.closePath();
  const mouth = new THREE.Path();
  mouth.moveTo(-half, 0); mouth.lineTo(half, 0); mouth.lineTo(half, height * .5);
  mouth.quadraticCurveTo(half, height, 0, height); mouth.quadraticCurveTo(-half, height, -half, height * .5); mouth.closePath();
  outline.holes.push(mouth);
  const concrete = new THREE.MeshStandardMaterial({ color: 0x8c8c7d, roughness: .96 });
  const collar = new THREE.Mesh(new THREE.ExtrudeGeometry(outline, { depth: 10, bevelEnabled: true, bevelThickness: .18, bevelSize: .15, bevelSegments: 2, curveSegments: 16 }), concrete);
  collar.position.z = -8; collar.castShadow = collar.receiveShadow = true; portal.add(collar);
  const tunnelPositions=[],tunnelIndices=[],profile=[[-half,0],[-half,height*.5]];
  for(let i=1;i<=24;i++){const a=Math.PI-i*Math.PI/24;profile.push([half*Math.cos(a),height*.5+height*.5*Math.sin(a)]);}
  profile.push([half,0]);
  for(const z of [0,-22])for(const [x,y] of profile)tunnelPositions.push(x,y,z);
  for(let i=0;i<profile.length-1;i++){const j=i+profile.length;tunnelIndices.push(i,j,i+1,i+1,j,j+1);}
  const tunnelGeometry=new THREE.BufferGeometry();tunnelGeometry.setAttribute("position",new THREE.Float32BufferAttribute(tunnelPositions,3));tunnelGeometry.setIndex(tunnelIndices);tunnelGeometry.computeVertexNormals();
  const tunnel=new THREE.Mesh(tunnelGeometry,new THREE.MeshStandardMaterial({color:0x33372f,map:soil,roughness:1,side:THREE.DoubleSide}));tunnel.castShadow=tunnel.receiveShadow=true;portal.add(tunnel);
  const portalFloor = box([half * 2, .2, 24], [0, .12, -10], yardMat, portal);
  // Occludes daylight behind the mouth so the opening reads as depth. Must
  // survive the authored swap below, or the portal becomes a freestanding arch
  // with the hillside visible straight through it.
  const backstop = box([half * 2, height, .2], [0, height / 2, -22], new THREE.MeshBasicMaterial({ color: 0x040605 }), portal);
  for (const side of [-1, 1]) {
    const rubble=rockBody({size:[15, 10, 18],position:[side * 12, 3, -6]},rockMat,portal,design.rock_seed+(side+1),1.1); rubble.material=rockMat;
    box([.3, 4.5, .3], [side * (half + .45), 2.25, 2.5], metal, portal);
    const stripes = new THREE.InstancedMesh(new THREE.BoxGeometry(.36,.35,.36),new THREE.MeshStandardMaterial({color:0xc3a057,roughness:.8}),4);
    const pose = new THREE.Object3D();
    for(let i=0;i<4;i++){pose.position.set(side*(half+.45),.7+i*.9,2.5);pose.updateMatrix();stripes.setMatrixAt(i,pose.matrix);}portal.add(stripes);
    box([.45,.15,1.2],[side*3.5,4.6,1],new THREE.MeshBasicMaterial({color:0xffe6bc}),portal);
  }
  try {
    const authored=await authoredAsset(config.visuals.authored?.portal);
    if(authored){
      // The authored collar replaces the procedural masonry, but the recessed
      // tunnel, its floor and the backstop are what give the mouth depth.
      const keep=new Set([tunnel,portalFloor,backstop]);
      for(const child of portal.children)if(child.isMesh&&!keep.has(child))child.visible=false;
      authored.traverse(o=>{if(o.isMesh&&o.material.name.includes("Rock"))o.material=rockMat;});
      portal.add(authored);
    }
  } catch(error){console.warn("Authored portal unavailable",error);}
  const portalLight = new THREE.PointLight(0xffd9a4, 80, 18, 2); portalLight.position.set(0,4,-4);portal.add(portalLight);
  // #360: the cut used to be made by deleting triangles whose centroid fell
  // inside a corridor, which can only ever punch a ragged hole through a
  // shell -- the edges followed the tessellation, not an excavation, and you
  // could see daylight through the crescent it left. The hill is now a
  // continuous surface that is *graded down* into a cut: a flat floor at yard
  // level running in to the portal, battered side slopes, and full ground
  // behind the face the portal is set into. Subdivision goes up because the
  // batter and the face need vertices to resolve against.
  const hillSpec=design.portal_hill;
  const hillGeometry=new THREE.PlaneGeometry(hillSpec.size[0],hillSpec.size[2],96,96);
  hillGeometry.rotateX(-Math.PI/2);hillGeometry.translate(...hillSpec.position);
  const hp=hillGeometry.attributes.position;
  const cutHalf=hillSpec.aperture_half_width_m, batter=hillSpec.cut_batter_m ?? 10;
  const faceZ=data.portal_position[2];
  for(let i=0;i<hp.count;i++){
    const x=hp.getX(i),z=hp.getZ(i),r=Math.pow(x/(hillSpec.size[0]/2),2)+Math.pow((z-hillSpec.position[2])/(hillSpec.size[2]/2),2);
    const shape=Math.max(0,1-r),front=THREE.MathUtils.smoothstep(-z,66,95);
    const ground=hillSpec.size[1]*shape*front*(.9+.08*Math.sin(x*.041)+.06*Math.cos(z*.031));
    // 0 inside the corridor, 1 out beyond the batter.
    const lateral=THREE.MathUtils.smoothstep(Math.abs(x),cutHalf,cutHalf+batter);
    // 0 behind the portal face, 1 at and in front of it. The band sits wholly
    // behind the portal so the cut is fully open where the collar stands --
    // centring it on the portal leaves roughly 7 m of ground over a 7 m
    // opening and buries the set.
    const ahead=THREE.MathUtils.smoothstep(z,faceZ-5,faceZ-1);
    const excavated=(1-lateral)*ahead;
    hp.setY(i,ground*(1-excavated));
  }
  hillGeometry.computeVertexNormals();
  const hill=new THREE.Mesh(hillGeometry,rockMat);hill.castShadow=hill.receiveShadow=true;root.add(hill);
  try{const mass=await authoredAsset(config.visuals.authored.portal_hill);if(mass){mass.traverse(o=>{if(o.isMesh)o.material=rockMat;});hill.visible=false;root.add(mass);}}catch(e){console.warn("Detailed portal terrain unavailable",e.message);}
  const roadGeometry = new THREE.PlaneGeometry(12, 750, 2, 80);
  roadGeometry.rotateX(-Math.PI / 2);
  roadGeometry.translate(0, 0, 300);
  const roadVertices = roadGeometry.attributes.position;
  for (let i = 0; i < roadVertices.count; i++)
    roadVertices.setY(
      i,
      elevation(roadVertices.getX(i), roadVertices.getZ(i)) + 0.3,
    );
  roadGeometry.computeVertexNormals();
  const roadMap = soil.clone();
  roadMap.repeat.set(2, 100);
  const road = new THREE.Mesh(
    roadGeometry,
    varyTexture(new THREE.MeshStandardMaterial({
      map: roadMap,
      roughness: 1,
      color: 0x989078,
    })),
  );
  road.receiveShadow = true;
  root.add(road);
  vegetation(root,data.tree_count,elevation,data.tree_seed);
  for (const [x, z] of design.tank_positions) {
    const tank = new THREE.Mesh(
      new THREE.CylinderGeometry(4, 4, 10, 24),
      metal,
    );
    tank.position.set(x, 5, z);
    tank.castShadow = true;
    root.add(tank);
  }
  for (const [index, [x, z]] of design.stockpiles.entries()) {
    const pileGeometry = new THREE.SphereGeometry(1, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2);
    const pp = pileGeometry.attributes.position;
    for(let i=0;i<pp.count;i++){const k=1+.13*Math.sin(i*2.71+index);pp.setXYZ(i,pp.getX(i)*k,pp.getY(i),pp.getZ(i)*k);}pileGeometry.computeVertexNormals();
    const pile = new THREE.Mesh(pileGeometry, rockMat);pile.position.set(x,.15,z);pile.scale.set(6,4,5);pile.castShadow=pile.receiveShadow=true;root.add(pile);
  }
  // Lightweight original service-yard details. Placements are authored, not survey data.
  const fencePoints=design.fence.map(p=>new THREE.Vector3(p[0],1.8,p[1]));
  const fenceMat=new THREE.MeshStandardMaterial({color:0x68716c,roughness:.7,metalness:.65});
  for(let i=1;i<fencePoints.length;i++) {
    const a=fencePoints[i-1],b=fencePoints[i],n=Math.ceil(a.distanceTo(b)/4),pose=new THREE.Object3D();
    const posts=new THREE.InstancedMesh(new THREE.CylinderGeometry(.075,.075,3.6,6),fenceMat,n+1);
    for(let j=0;j<=n;j++){pose.position.copy(a).lerp(b,j/n);pose.scale.setScalar(Math.abs(pose.position.x)<6?0:1);pose.updateMatrix();posts.setMatrixAt(j,pose.matrix);}root.add(posts);
    for(const y of [.5,2,3.3]){if(a.x<0&&b.x>0){root.add(line([[a.x,y,a.z],[-6,y,a.z]],0x6c756c,.65));root.add(line([[6,y,a.z],[b.x,y,b.z]],0x6c756c,.65));}else root.add(line([[a.x,y,a.z],[b.x,y,b.z]],0x6c756c,.65));}
  }
  const conveyor = new THREE.Group();conveyor.position.set(33,0,47);conveyor.rotation.z=-.15;root.add(conveyor);
  box([25,.5,2.5],[0,4,0],dark,conveyor);box([25,.12,.2],[0,4.6,1.3],metal,conveyor);box([25,.12,.2],[0,4.6,-1.3],metal,conveyor);
  for(const x of [-10,0,10]){box([.25,4,.25],[x,2,-1],metal,conveyor);box([.25,4,.25],[x,2,1],metal,conveyor);}
  for(const x of [-76,-68,62,70]){box([1.8,.8,.7],[x,.4,8],concrete,root);}
  for(const x of [-7,7]){
    const drain=box([.35,.08,102],[x,.16,11],metal,root);drain.receiveShadow=true;
  }
  const workingVehicles=[];
  for (const spec of design.parked_vehicles) {
    const vehicle=createVehicle(spec.id,vehicleModel,{oreMap:aggregate,authoredHauler:config.visuals.authored?.hauler,authoredOverview:config.visuals.authored?.hauler_overview});vehicle.root.position.fromArray(spec.position);
    // Use the overview LOD: it carries the authored hauler body and wheels.
    // The detail LOD left only a bare cargo box standing in the yard, which is
    // why this vehicle was previously parked outside the arrival framing.
    // The overview LOD's cargo proxy is unlit, so a loaded bed reads as a flat
    // mauve patch in a lit scene. This machine is parked, so it is empty.
    workingVehicles.push(vehicle);vehicle.root.rotation.y=spec.heading;vehicle.detail.visible=false;vehicle.overview.visible=true;
    vehicle.cargo.visible=false;vehicle.proxyCargo.visible=false;
    // The painted contact shadow must not enter the shadow map: shadow casting
    // ignores the alpha that makes it an ellipse, so the whole 3.4 by 9 quad
    // was casting a crisp black rectangle onto the yard under the machine.
    vehicle.root.traverse(o=>{if(o.isMesh&&o.name!=="contact-shadow")o.castShadow=o.receiveShadow=true;});root.add(vehicle.root);
  }
  await Promise.all(workingVehicles.map(v=>v.ready));
  // Rigid fallback tyres use an explicit horizontal axle. Some imported wheel
  // meshes carried a flattened attachment transform from the older export.
  const tyreGeometry=new THREE.CylinderGeometry(vehicleModel.wheels.radius_m,vehicleModel.wheels.radius_m,vehicleModel.wheels.width_m,28),hubGeometry=new THREE.CylinderGeometry(.22,.22,vehicleModel.wheels.width_m+.015,16);
  const rubber=new THREE.MeshStandardMaterial({color:0x171d1d,roughness:.94}),hubMaterial=new THREE.MeshStandardMaterial({color:0x757c74,roughness:.5,metalness:.7});
  for(const vehicle of workingVehicles)for(const pivot of vehicle.wheels){
    for(const child of pivot.children)child.visible=false;
    for(const [geometry,material] of [[tyreGeometry,rubber],[hubGeometry,hubMaterial]]){const mesh=new THREE.Mesh(geometry,material);mesh.rotation.z=Math.PI/2;mesh.castShadow=mesh.receiveShadow=true;pivot.add(mesh);}
  }

  const activity=yardActivity(root,design.activity);let siteTime=0;
  lightRig(root, 120).position.y=120*(design.sky?.sun_height_ratio||1.7);
  heightMap.dispose();
  // #391: the sky was a single flat colour, so distant ridges sat at the same
  // contrast as the foreground and the terrain read as a tilted model. A dome
  // gives the day a defined structure: a muted zenith, a pale haze band at the
  // horizon that the fog colour matches so distant ground dissolves into it,
  // and a warm bias toward the key light. Rutongo is two degrees south, so the
  // sun sits high and the haze is thick rather than a crisp temperate blue.
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(4200, 32, 20),
    new THREE.ShaderMaterial({
      side: THREE.BackSide, depthWrite: false, fog: false,
      uniforms: {
        zenith: { value: new THREE.Color(0x3f6f93) },
        horizon: { value: new THREE.Color(0xb3bcb7) },
        glow: { value: new THREE.Color(0xffe9c6) },
        sun: { value: new THREE.Vector3(-1, 1.7, 0.7).normalize() },  // matches lightRig's key
      },
      vertexShader: `varying vec3 vDir;
        void main(){ vDir = normalize(position);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `uniform vec3 zenith, horizon, glow; uniform vec3 sun; varying vec3 vDir;
        void main(){
          vec3 d = normalize(vDir);
          float h = clamp(d.y, 0.0, 1.0);
          // Thick tropical haze: the band holds low and falls away quickly.
          vec3 c = mix(horizon, zenith, pow(h, 0.42));
          float toSun = max(dot(d, normalize(sun)), 0.0);
          c = mix(c, glow, pow(toSun, 5.0) * 0.55 + pow(toSun, 48.0) * 0.4);
          // Below the horizon, settle to the haze so the ground plane meets sky cleanly.
          c = mix(horizon * 0.86, c, smoothstep(-0.06, 0.03, d.y));
          gl_FragColor = vec4(c, 1.0);
        }`,
    }),
  );
  if(design.sky?.path)try{
    const photo=await texture(design.sky.path);sky.material.dispose();sky.material=new THREE.MeshBasicMaterial({map:photo,side:THREE.BackSide,depthWrite:false,fog:false,toneMapped:false});sky.rotation.y=design.sky.rotation_y;
  }catch(error){console.warn("Sky photograph unavailable; using the authored atmosphere",error.message);}
  sky.frustumCulled = false;
  root.add(sky);

  return {root,portal:portal.position.clone(),elevation,update(delta,reduced=false){
    siteTime=Math.min(haul.duration_s,siteTime+(reduced?0:delta));const pose=sampleSurfaceHaul(haul,siteTime);
    for(const vehicle of workingVehicles){vehicle.root.position.fromArray(pose.position);vehicle.root.position.y+=yard.position.y-haul.ground_y_m;vehicle.root.rotation.y=pose.heading;
      vehicle.wheels.forEach((wheel,i)=>{const z=wheel.position.z,front=z>0,side=wheel.position.x<0?0:1;wheel.rotation.x=pose.wheelAngles[(front?2:0)+side];wheel.rotation.y=front?pose.steering[side]:0;if(wheel.userData.mirror){wheel.userData.mirror.rotation.x=wheel.rotation.x;wheel.userData.mirror.rotation.y=wheel.rotation.y;}});
    }
    root.updateMatrixWorld(true);activity.update(siteTime,reduced,pose.speed>.05?workingVehicles.map(v=>v.root):[]);
  },diagnostics(){return {...sampleSurfaceHaul(haul,siteTime),groundY:yard.position.y,tyreBottoms:workingVehicles.flatMap(v=>v.wheels.map(w=>w.getWorldPosition(new THREE.Vector3()).y-vehicleModel.wheels.radius_m))};}};
}
